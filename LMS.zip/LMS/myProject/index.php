<?php 

session_start();
 //error_reporting(0);
include('admin/includes/dbconnection.php');
$where = '';
	if(isset($_GET['category'])){
		$catid = $_GET['category'];
		$where = 'WHERE category_id = '.$catid;
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Library Management System  - Home page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="" />

	<!-- css --> 
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<!-- <link rel="stylesheet" href="materialize/css/materialize.min.css" 
		media="screen,projection" /> -->
	<link href="css/bootstrap.min.css" rel="stylesheet" />
	<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet"> 
	<link href="css/flexslider.css" rel="stylesheet" /> 
	<link rel="stylesheet" type="text/css" href="css/zoomslider.css" />
	<link href="css/style.css" rel="stylesheet" />
	<style>
  		.dataTables_filter {
			display: none; 
		}
  	</style>	
</head>
<body>
	<div id="wrapper" class="home-page"> 
		
		<!-- start header -->
		<?php include('includes/header.php') ?>
		<!-- end header -->
		<section id="banner">
			
				
			<div id="slider"

			 data-zs-src=<?php
                    $sql="SELECT * from tblslider_img where img_id='5'";
                    $sql1="SELECT * from tblslider_img where img_id='2'";
                    $sql3="SELECT * from tblslider_img where img_id='4'";
                    $query = $dbh -> prepare($sql);
                    $query1 = $dbh -> prepare($sql1);
                    $query3 = $dbh -> prepare($sql3);
                    $query->execute();
                    $query1->execute();
                     $query3->execute();
                    $results=$query->fetchAll(PDO::FETCH_OBJ);
                    $results1=$query1->fetchAll(PDO::FETCH_OBJ);
                    $results3=$query3->fetchAll(PDO::FETCH_OBJ);
                   
                    if($query->rowCount() > 0)
                    {
                      foreach($results as $row)
                      { 
                        ?>

			<?php 
                       
                      }
                    } 


                    ?>


                    <?php

                    if($query3->rowCount() > 0)
                    {
                      foreach($results3 as $row3)
                      { 
                        ?> 

                      

			<?php 
                       
                      }
                    } 




                    ?>


                    <?php

                    if($query1->rowCount() > 0)
                    {
                      foreach($results1 as $row1)
                      { 
                        ?> 

                       
			<?php 
                       
                      }
                    } 




                    ?>



			 >
			
			</div>
                          
			<!-- end slider --> 

		</section>  
		<section class="projects">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="aligncenter"><h2 class="aligncenter">Search Books</h2></div>
						<br/>
					</div>
				</div>

				<div class="row service-v1 margin-bottom-40">
					<div class="row">
	        	<div class="col-sm-8 col-sm-offset-2">
	        		<?php
	        			if(isset($_SESSION['error'])){
	        				echo "
	        					<div class='alert alert-danger'>
	        						".$_SESSION['error']."
	        					</div>
	        				";
	        				unset($_SESSION['error']);
	        			}
	        		?>
	        		<div class="box">
	        			<div class="box-header with-border">
	        				<div class="input-group">
				                <input type="text" class="form-control input-lg" id="searchBox" 
				                placeholder="Search for ISBN, Title or Author">
				                <span class="input-group-btn">
				                    <button type="button" class="btn btn-primary btn-flat btn-lg">
				                    	<i class="fa fa-search"></i> </button>
				                </span>
				            </div>
	        			</div>
	        			<div class="box-body">
	        				<div class="input-group col-sm-5">
				                <span class="input-group-addon">Category:</span>
				                <select class="form-control" id="catlist">
				                	<option value=0>ALL</option>
				                	<?php
				                		$sql = "SELECT * FROM tblcategory";
				                		$query = $con->query($sql);
				                		while($catrow = $query->fetch_assoc()){
				                			$selected = ($catid == $catrow['id']) ? " selected" : "";
				                			echo "
				                				<option value='".$catrow['id']."' ".$selected.">".$catrow['name']."</option>
				                			";
				                		}
				                	?>
				                </select>
				             </div>
	        				<table class="table table-bordered table-striped" id="booklist">
			        			<thead>
			        				<th>ISBN</th>
			        				<th>Title</th>
			        				<th>Author</th>
			        				<th>Status</th>
			        			</thead>
			        			<tbody>
			        			<?php
			        				$sql = "SELECT * FROM tblbooks $where";
			        				$query = $con->query($sql);
			        				while($row = $query->fetch_assoc()){
			        					if ( $row['status'] == 0) {
			        						 
			        	$status ='<span class="label label-danger">not available</span>'; } 
			        	if ( $row['status'] == 1) {
			        						 
			        	$status ='<span class="label label-success"> available</span>'; } 
			        	if ( $row['status'] == 3) {
			        						 
			        	$status ='<span class="label label-success"> available</span>'; } 

			        					;
			        					echo "
			        						<tr>
			        							
			        							<td>".$row['isbn']."</td>
			        							<td>".$row['title']."</td>
			        							<td>".$row['author']."</td>
			        							<td>".$status."</td>
			        						</tr>
			        					";
			        				}
			        			?>
			        			</tbody>
			        		</table>
	        			</div>
	        		</div>
	        	</div>
	        </div>
	
				</div>
			</div>
		</section>

		<section class="section-padding gray-bg">
			<div class="container">
				
				<div class="row">

					<div class="col-md-6 col-sm-6">
						
							<?php
                    $sql="SELECT * from tblslider_img where img_id='7'";
                    $query = $dbh -> prepare($sql);
                    $query->execute();
                    $results=$query->fetchAll(PDO::FETCH_OBJ);
                   
                    if($query->rowCount() > 0)
                    {
                      foreach($results as $row)
                      { ?>
							
							<?php }}?>
						</div>
					</div>
					<div class="col-md-6 col-sm-6">
						<div class="about-text">
							<h3>About Us</h3>
			<p>Welcome to our Computerized Department Library Project! We are dedicated to revolutionizing the way information is managed and accessed within our department.</p>
							
							<a href="about.php" class="btn btn-primary waves-effect waves-dark">Learn More</a>
						</div>
					</div>
				</div>
			</div>
		</section>	  

	</div>
	<a href="#" class="scrollup waves-effect waves-dark"><i class="fa fa-angle-up HillSide"></i></a>
	<script src="js/jquery.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="materialize/js/materialize.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.fancybox.pack.js"></script>
	<script src="js/jquery.fancybox-media.js"></script>  
	<script src="js/jquery.flexslider.js"></script>
	
	<!-- Vendor Scripts -->
	<script src="js/modernizr.custom.js"></script>
	<script src="js/jquery.zoomslider.min.js"></script>
	<script src="js/jquery.isotope.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script> 
	<script src="js/custom.js"></script>


	<script src="admin/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="admin/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

	<script>
$(function(){
	$('#catlist').on('change', function(){
		if($(this).val() == 0){
			window.location = 'index.php';
		}
		else{
			window.location = 'index.php?category='+$(this).val();
		}
		
	});
});
</script>
<script>
  $(function () {
    $('#example1').DataTable()
  	var bookTable = $('#booklist').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : true,
      'ordering'    : true,
      'info'        : false,
      'autoWidth'   : false
    })

    $('#searchBox').on('keyup', function(){
    	bookTable.search(this.value).draw();
	});

  })
</script>
<?php include 'includes/login_modal.php'; ?>

</body>
</html>