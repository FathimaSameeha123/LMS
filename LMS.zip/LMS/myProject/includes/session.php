<?php
	include('admin/includes/dbconnection.php');
	session_start();

	if(isset($_SESSION['student'])){
		$sql = "SELECT * FROM tblstudents WHERE id = '".$_SESSION['student']."'";
		$query = $con->query($sql);
		$student = $query->fetch_assoc();
	}

?>