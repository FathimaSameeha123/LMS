<header>

            <div class="navbar navbar-default navbar-static-top">
				<div class="container">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
			
						<a class="navbar-brand" href="index.php"><i class="icon-info-blocks material-icons"></i>LIBRARY MANAGEMENT SYSTEM </a>
					</div>
					
					<div class="navbar-collapse collapse ">

						<ul class="nav navbar-nav">
							<?php
            if(isset($_SESSION['student'])){
              $photo = (!empty($student['photo'])) ? 'admin/studenimages/'.$student['photo'] : 'img/avatar.png';
              echo "
              
                <li class='user user-menu'>
                  <a href='#'>
                    <img src='".$photo."' class='user-image' alt='User Image' height='80px' width='80px'>
                    <span class=''>".$student['firstname'].' '.$student['lastname']."</span>
                  </a>
                </li>


              ";
            } ?>
							
							<?php
            if(isset($_SESSION['student'])){

              echo "
                
                <li><a href='logout.php'></i> LOGOUT</a></li>

              ";
            }
            else{
              echo "
              <li class='HillSide'><a class='waves-effect waves-dark' href='index.php'>Home</a></li> 
              <li><a class='waves-effect waves-dark' href='about.php'>About Us</a></li>
                <li><a href='#login' data-toggle='modal'></i>Student Login</a></li>
                <li><a class='waves-effect waves-dark' href='admin' >Admin Login </a></li>

              ";
            } 
          ?>
          
						</ul>
					</div>
				</div>
			</div>
		</header>