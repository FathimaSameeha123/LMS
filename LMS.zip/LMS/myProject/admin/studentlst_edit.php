<?php
session_start();
//error_reporting(0);
include('includes/dbconnection.php');

 if(isset($_POST['insert']))
{
    $trid= $_SESSION['editbid'];
   $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $student_id = $_POST['student_id'];
  

    $sql4="update tblstudents set firstname=:firstname, lastname=:lastname, student_id=:student_id where id=:trid";
    $query=$dbh->prepare($sql4);
    $query->bindParam(':firstname',$firstname,PDO::PARAM_STR);
  $query->bindParam(':lastname',$lastname,PDO::PARAM_STR);
  $query->bindParam(':student_id',$student_id,PDO::PARAM_STR);
  $query->bindParam(':trid',$trid,PDO::PARAM_STR);

    if ($query->execute())
    {
        echo '<script>alert("updated successfuly")</script>';
    }else{
        echo '<script>alert("update failed! try again later")</script>';
    }
}

?>
<div class="card-body">
 
  <?php
  $eid=$_POST['edit_id4'];
  //echo $eid;
  //$eid=3;
  $sql="SELECT * from tblstudents  where id=:eid";
  $query = $dbh -> prepare($sql);
  $query-> bindParam(':eid', $eid, PDO::PARAM_STR);
  $query->execute();
  $results=$query->fetchAll(PDO::FETCH_OBJ);
  if($query->rowCount() > 0)
  {
    foreach($results as $row)

        $photo = (!empty($row->photo )) ? './studenimages/'.($row->photo)  : './studenimages/profile.jpg';
      $_SESSION['editbid']=$row->id;
      {?>

        <h4 style="color: blue">Student Photo Update</h4>
         <form class="form-sample"  method="post" enctype="multipart/form-data">
        
         <div class="row">
                    <div class="form-group col-md-6">
                        <label class="col-sm-12 pl-0 pr-0">Firstname Name</label>
                        <div class="col-sm-12 pl-0 pr-0">
                            <input type="text" name="firstname" id="firstname" class="form-control" value="<?php  echo $row->firstname;?>" required />
                        </div>
                    </div>
                    <div class="form-group col-md-6">
                        <label class="col-sm-12 pl-0 pr-0">Last Name</label>
                        <div class="col-sm-12 pl-0 pr-0">
                            <input type="text" name="lastname" id="lastname" class="form-control" value="<?php  echo $row->lastname;?>" required />
                        </div>
                    </div>
 </div>
 <div class="row">
<div class="form-group col-md-6">
                        <label class="col-sm-12 pl-0 pr-0">Student Registration No</label>
                        <div class="col-sm-12 pl-0 pr-0">
                            <input type="text" name="student_id" id="student_id" class="form-control" value="<?php  echo $row->student_id;?>" required />
                        </div>
                    </div>
 </div>
<button type="submit" name="insert" class="btn btn-primary btn-fw mr-2" style="float: left;">Update</button>
    </form>
        <?php 
      }
    } ?>
  </div>