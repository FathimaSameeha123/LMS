<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if(isset($_POST['insert']))
{
    $trid= $_SESSION['editbid'];
   $isbn = $_POST['isbn'];
    $title = $_POST['title'];
    $category = $_POST['category'];
    $author = $_POST['author'];
    $publisher = $_POST['publisher'];
    $publish_year = $_POST['publish_year'];

    $sql4="update tblbooks set isbn=:isbn, title=:title, category_id=:category, author=:author, publisher=:publisher, publish_year=:publish_year  where id=:trid";
    $query=$dbh->prepare($sql4);
    $query->bindParam(':isbn',$isbn,PDO::PARAM_STR);
  $query->bindParam(':title',$title,PDO::PARAM_STR);
  $query->bindParam(':category',$category,PDO::PARAM_STR);
  $query->bindParam(':author',$author,PDO::PARAM_STR);
  $query->bindParam(':publisher',$publisher,PDO::PARAM_STR);
  $query->bindParam(':publish_year',$publish_year,PDO::PARAM_STR);
  $query->bindParam(':trid',$trid,PDO::PARAM_STR);

    if ($query->execute())
    {
        echo '<script>alert("updated successfuly")</script>';
    }else{
        echo '<script>alert("update failed! try again later")</script>';
    }
}
?>
<div class="card-body">
    <?php
    $trid=$_POST['edit_id4'];
    $sql2="SELECT *, tblbooks.id AS bookid FROM tblbooks LEFT JOIN tblcategory ON tblcategory.id=tblbooks.category_id WHERE tblbooks.id=:trid";
    $query2 = $dbh -> prepare($sql2);
    $query2-> bindParam(':trid', $trid, PDO::PARAM_STR);
    $query2->execute();
    $results=$query2->fetchAll(PDO::FETCH_OBJ);
    if($query2->rowCount() > 0)
    {
        foreach($results as $row)
        {
            $_SESSION['editbid']=$row->bookid;
            ?>
            <form class="form-sample"  method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="form-group col-md-6">
                        <label class="col-sm-12 pl-0 pr-0">ISBN</label>
                        <div class="col-sm-12 pl-0 pr-0">
                            <input type="text" name="isbn" id="isbn" class="form-control" value="<?php  echo $row->isbn;?>" required />
                        </div>
                    </div>
                    <div class="form-group col-md-6">
                        <label class="col-sm-12 pl-0 pr-0">Title</label>
                        <div class="col-sm-12 pl-0 pr-0">
                            <input type="text" name="title" id="title" class="form-control" value="<?php  echo $row->title;?>" required />
                        </div>
                    </div>
 </div>

  <div class="row">
                    <div class="form-group col-md-6">
                        <label class="col-sm-12 pl-0 pr-0">Category</label>
                        <div class="col-sm-12 pl-0 pr-0">
                             <select class="form-control" name="category" id="category">
                            
                        <?php
                       $cateid=$row->category_id;
                          $sql = "SELECT * FROM tblcategory where id='$cateid'";
                          $query = $con->query($sql);
                          while($crow = $query->fetch_assoc()){
                            echo "
                              <option selected value='".$crow['id']."'>".$crow['name']."</option>
                            ";
                          }
                        ?>
<option value="" >- Select -</option>
                         <?php
                          $sql = "SELECT * FROM tblcategory";
                          $query = $con->query($sql);
                          while($crow = $query->fetch_assoc()){
                            echo "
                              <option value='".$crow['id']."'>".$crow['name']."</option>
                            ";
                          }
                        ?>
                      </select>
                        </div>
                    </div>

                    <div class="form-group col-md-6">
                        <label class="col-sm-12 pl-0 pr-0">Author</label>
                        <div class="col-sm-12 pl-0 pr-0">
                            <input type="text" name="author" id="author" class="form-control" value="<?php  echo $row->author;?>" required />
                        </div>
                    </div>
               
             </div>
                    <div class="row">
                    <div class="form-group col-md-6">
                        <label class="col-sm-12 pl-0 pr-0">Publisher</label>
                        <div class="col-sm-12 pl-0 pr-0">
                            <input type="text" name="publisher" id="publisher" class="form-control" value="<?php  echo $row->publisher;?>" required />
                        </div>
                    </div>
                    <div class="form-group col-md-6">
                        <label class="col-sm-12 pl-0 pr-0">Publish year</label>
                        <div class="col-sm-12 pl-0 pr-0">
                            <input type="number" name="publish_year" id="publish_year" class="form-control" value="<?php  echo $row->publish_year;?>" required />
                        </div>
                    </div>
 </div>
                <button type="submit" name="insert" class="btn btn-primary btn-fw mr-2" style="float: left;">Update</button>
            </form>
            <?php 
        }
    } ?>
</div>