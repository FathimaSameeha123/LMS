<?php
session_start();
//error_reporting(0);
include('includes/dbconnection.php');
if(isset($_POST['insert']))
{
    $eib= $_SESSION['editbid'];
    $category=$_POST['category'];

    $sql4="update tblborrow set CategoryName=:category where id=:eib";
    $query=$dbh->prepare($sql4);
    $query->bindParam(':category',$category,PDO::PARAM_STR);
    
    $query->bindParam(':eib',$eib,PDO::PARAM_STR);
    $query->execute();
    if ($query->execute())
    {
        echo '<script>alert("updated successfuly")</script>';
    }else{
        echo '<script>alert("update failed! try again later")</script>';
    }
}
?>
<div class="card-body">
    <?php
    $eid=$_POST['edit_id4'];
    $sql2="SELECT * from tblborrow inner join tblstudents on  tblstudents.id=tblborrow.student_id inner join tblbooks on tblborrow.book_id=tblbooks.id where tblborrow.id=:eid";
    $query2 = $dbh -> prepare($sql2);
    $query2-> bindParam(':eid', $eid, PDO::PARAM_STR);
    $query2->execute();
    $results=$query2->fetchAll(PDO::FETCH_OBJ);
    if($query2->rowCount() > 0)
    {
        foreach($results as $row)
        {
            $_SESSION['editbid']=$row->id;
            ?>
            <form class="form-sample"  method="post" enctype="multipart/form-data">


                      <div class="form-group">
                    <label for="isbn" class="col-sm-12 pl-0 pr-0">Student Name</label>

                    <div class="col-sm-9">
                    
                       <select class="form-control" name="student" >
                     
                        <option value="" selected="" disabled=""> Please Select Student Here.</option>
                        <?php  
                            $sql = "SELECT * from tblborrow inner join tblstudents on  tblstudents.id=tblborrow.student_id inner join tblbooks on tblborrow.book_id=tblbooks.id where tblborrow.id='$eid'";
                            $qry = $con->query($sql);
                            while($row = $qry->fetch_array()):
                        ?>
                          <option selected value="<?php echo $row['student_id'] ?>"><?php echo ucwords($row['firstname'].' '.$row['lastname']) . ' ['.$row['student_id'].']' ?></option>
                       
                        <?php endwhile;  ?>
                        <option value="" selected="" disabled=""> Please Select Student Here.</option>

                         <?php  
                            $sql = "SELECT * FROM tblstudents order by concat(firstname,' ',lastname) asc ";
                            $qry = $con->query($sql);
                            while($rows = $qry->fetch_array()):
                        ?>
                          <option value="<?php echo $rows['student_id'] ?>"><?php echo ucwords($rows['firstname'].' '.$rows['lastname']) . ' ['.$rows['student_id'].']' ?></option>
                       
                        <?php endwhile;  ?>
                      </select>
                    </div>
                </div>

            <div class="form-group">
                    <label for="isbn" class="col-sm-12 pl-0 pr-0">Student Name</label>

                    <div class="col-sm-9">
                    
                       <select class="form-control" name="student" >
                     
                        <option value="" selected="" disabled=""> Please Select Student Here.</option>
                        <?php  
                            $sql = "SELECT * from tblborrow inner join tblstudents on  tblstudents.id=tblborrow.student_id inner join tblbooks on tblborrow.book_id=tblbooks.id where tblborrow.id='$eid' ";
                            $qry = $con->query($sql);
                            while($row = $qry->fetch_array()):
                        ?>
                           <option value="<?php echo $row['isbn'] ?>"><?php echo ucwords($row['title']) . ' ['.$row['isbn'].']' ?></option>
                       
                        <?php endwhile;  ?>
                        <option value="" selected="" disabled=""> Please Select Student Here.</option>

                         <?php  
                            $sql = "SELECT * FROM tblbooks where status = 0 order by title asc ";
                            $qry = $con->query($sql);
                            while($rows = $qry->fetch_array()):
                        ?>
                           <option value="<?php echo $row['isbn'] ?>"><?php echo ucwords($row['title']) . ' ['.$row['isbn'].']' ?></option>
                       
                        <?php endwhile;  ?>
                      </select>
                    </div>
                </div>
            
             
                <button type="submit" name="insert" class="btn btn-primary btn-fw mr-2" style="float: left;">Update</button>
            </form>
            <?php 
        }
    } ?>
</div>