 <nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item nav-profile">
            <?php
            $aid=$_SESSION['odmsaid'];
            $sql="SELECT * from  tbladmin where ID=:aid";
            $query = $dbh -> prepare($sql);
            $query->bindParam(':aid',$aid,PDO::PARAM_STR);
            $query->execute();
            $results=$query->fetchAll(PDO::FETCH_OBJ);
            $cnt=1;
            if($query->rowCount() > 0)
            { 
                foreach($results as $row)
                {
                    ?>
                   
                        <div class="nav-profile-text d-flex flex-column">
                            <span class="font-weight-bold mb-2"><?php  echo $row->AdminName;?></span>
                            
                        </div>
                    </a>
                    <?php 
                }
            } ?>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="dashboard.php">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
            </a>
        </li>

         <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
                <span class="menu-title">Transaction management</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-library"></i>
            </a>
            <div class="collapse" id="ui-basic">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="borrow.php">Borrow</a></li>
                    <li class="nav-item"> <a class="nav-link" href="bookreturn.php">Return</a></li>
                </ul>
            </div>
        </li>


        <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#ui-book" aria-expanded="false" aria-controls="ui-basic">
                <span class="menu-title">Book management</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-library-books"></i>
            </a>
            <div class="collapse" id="ui-book">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="booklist.php">Book List</a></li>
                    <li class="nav-item"> <a class="nav-link" href="category.php">Category</a></li>
                </ul>
            </div>
        </li>
<!-- //Faculties -->


        <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#ui-student" aria-expanded="false" aria-controls="ui-basic">
                <span class="menu-title">Students management</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-archive mdi-human-male-female"></i>
            </a>
            <div class="collapse" id="ui-student">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="studentlist.php">Student List</a></li>
                    
                </ul>
            </div>
        </li>
       
     

     
    
     
        
        
    </ul>
</nav>