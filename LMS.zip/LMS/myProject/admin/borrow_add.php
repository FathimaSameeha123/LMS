<?php

include('includes/checklogin.php');
check_login();
  if(isset($_POST['save'])){
    $student = $_POST['student'];
    
    $sql = "SELECT * FROM tblstudents WHERE student_id = '$student'";
    $query = $con->query($sql);
    if($query->num_rows < 1){
      if(!isset($_SESSION['error'])){
        $_SESSION['error'] = array();
      }
       echo '<script>alert(" Student not found")</script>';
     
    }
    else{
      $row = $query->fetch_assoc();
      $student_id = $row['id'];

      $added = 0;
      foreach($_POST['isbn'] as $isbn){
        if(!empty($isbn)){
          $sql = "SELECT * FROM tblbooks WHERE isbn = '$isbn' AND status != 1";
          $query = $con->query($sql);
          if($query->num_rows > 0){
            $brow = $query->fetch_assoc();
            $bid = $brow['id'];

            $sql = "INSERT INTO tblborrow (student_id, book_id, date_borrow) VALUES ('$student_id', '$bid', NOW())";
            if($con->query($sql)){
              $added++;
              $sql = "UPDATE tblbooks SET status = 1 WHERE id = '$bid'";
              $con->query($sql);

            }
            else{
              if(!isset($_SESSION['error'])){
                $_SESSION['error'] = array();
              }
              $_SESSION['error'][] = $conn->error;

            }

          }
          else{
            if(!isset($_SESSION['error'])){
              $_SESSION['error'] = array();
            }
         
             echo '<script>alert(" Book with ISBN unavailable")</script>';
          }
    
        }
      }
      if($added > 0){
        $book = ($added == 1) ? 'Book' : 'Books';
       // $_SESSION['success'] = $added.' '.$book.' successfully borrowed';
echo '<script>alert(" successfully borrowed ")</script>';
 echo "<script>window.location.href='borrow.php'</script>";
      }

    }
  } 
  else{
  
    echo '<script>alert(" Fill up add form first")</script>';
     echo "<script>window.location.href='borrow.php'</script>";
  }


?>