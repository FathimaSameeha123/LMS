<?php
include('includes/checklogin.php');
check_login();

if(isset($_GET['del'])){    
  $cmpid=$_GET['del'];
  $query=mysqli_query($con,"delete from tblborrow where id='$cmpid'");
  echo "<script>alert(' record deleted.');</script>";   
  echo "<script>window.location.href='borrow.php'</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<?php @include("includes/head.php");?>
<body>
  <div class="container-scroller">
    <!-- partial:../../partials/_navbar.html -->
    <?php @include("includes/header.php");?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:../../partials/_sidebar.html -->
      <?php @include("includes/sidebar.php");?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
               <div class="modal-header">
                <h5 class="modal-title" style="float: left;">Borrow Books </h5>
              </div>
              <div class="col-md-12 mt-4">
                <form class="forms-sample" method="post" action="borrow_add.php" enctype="multipart/form-data" class="form-horizontal">
                  

                  <div class="form-group">
                    <label for="isbn" class="col-sm-3 control-label">Student Name</label>

                    <div class="col-sm-9">
                    
                       <select class="form-control" name="student" >
                     
                        <option value="" selected="" disabled=""> Please Select Student Here.</option>
                        <?php  
                            $sql = "SELECT * FROM tblstudents order by concat(firstname,' ',lastname) asc ";
                            $qry = $con->query($sql);
                            while($row = $qry->fetch_array()):
                        ?>
                          <option value="<?php echo $row['student_id'] ?>"><?php echo ucwords($row['firstname'].' '.$row['lastname']) . ' ['.$row['student_id'].']' ?></option>
                       
                        <?php endwhile;  ?>
                      </select>
                    </div>
                </div>

                  <div class="form-group">
                    <label for="isbn" class="col-sm-3 control-label">ISBN</label>

                    <div class="col-sm-9">
                     
                       <select class="form-control" name="isbn[]" >
                        <option value="" selected="" disabled=""> Please Select Book Here.</option>
                        <?php  
                            $books = "SELECT * FROM tblbooks where status = 0 || status = 3 order by title asc ";
                            $b_qry = $con->query($books);
                            $brows=array();
                            while($row = $b_qry->fetch_array()):
                               $brows[] = $row;
                        ?>
                           <option value="<?php echo $row['isbn'] ?>"><?php echo ucwords($row['title']) . ' ['.$row['isbn'].']' ?></option>
                        <?php endwhile;  ?>
                      </select>
                    </div>
                </div>


                  <span id="append-div"></span>
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                      <button class="btn btn-info btn-xs btn-flat" id="append"><i class="mdi mdi-assistant"></i> Book Field</button>
                    </div>
                </div>
                 
                  <button type="submit" style="float: left;" name="save" class="btn btn-primary mr-2 mb-4">Save</button>
                </form>
              </div>
            </div>
          </div>
          <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
              <!--  start  modal -->
              <div id="editData4" class="modal fade">
                <div class="modal-dialog modal-md">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Edit Student details</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body" id="info_update4">
                      <?php @include("borrow_edit.php");?>
                    </div>
                    <div class="modal-footer ">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    </div>
                    <!-- /.modal-content -->
                  </div>
                  <!-- /.modal-dialog -->
                </div>
                <!-- /.modal -->
              </div>
              <!--   end modal -->
              <!--  start  modal -->
              <div id="editData5" class="modal fade">
                <div class="modal-dialog modal-md">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">View Student details</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body" id="info_update5">
                      <?php @include("borrow_view.php");?>
                    </div>
                    <div class="modal-footer ">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    </div>
                    <!-- /.modal-content -->
                  </div>
                  <!-- /.modal-dialog -->
                </div>
                <!-- /.modal -->
              </div>
              <!--   end modal -->
              <!-- <div class="table-responsive p-3">
                <table class="table align-items-center table-flush table-hover table-bordered" id="dataTableHover"> -->
                  <div class="box-body">
              <table id="example1" class="table align-items-center table-flush  table-bordered">
                  <thead>

                    <tr>
                       <th class="text-center">No</th>
                      <th class="text-center"> Date</th>
                      <th>Student Registration No</th>
                      <th>Name</th>
                  <th>ISBN</th>
                  <th>Title</th>
                  <th>Status</th>
                     
                      <th class=" Text-center" style="width: 15%;">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $sql="SELECT *, tblstudents.student_id AS stud, tblstudents.id AS studentid, tblborrow.id AS browids, tblborrow.status AS borrowstatus FROM tblborrow LEFT JOIN tblstudents ON tblstudents.id=tblborrow.student_id LEFT JOIN tblbooks ON tblbooks.id=tblborrow.book_id ORDER BY date_borrow DESC";
                    $query = $dbh -> prepare($sql);
                    $query->execute();
                    $results=$query->fetchAll(PDO::FETCH_OBJ);
                    $cnt=1;
                    if($query->rowCount() > 0)
                    {
                      foreach($results as $row)
                      { 
                        if($row->borrowstatus ){
                        $status = '<span class="label bg-gradient-success">returned</span>';
                      }
                      else{
                        $status = '<span class="label bg-gradient-danger">not returned</span>';
                      }
                        ?>
                        <tr>
                          <td class="text-center"><?php echo htmlentities($cnt);?></td>
                          <td class="text-center"><?php  echo htmlentities(date("d-m-Y", strtotime($row->date_borrow)));?></td>
                          <td class=""><a href="#"class=" edit_data5" id="<?php echo  ($row->studentid); ?>" ><?php  echo htmlentities($row->stud);?></a></td>
                         <td class=""><?php  echo htmlentities($row->firstname.''. ($row->lastname)) ;?></td>
                          
                           <td class=""><?php  echo htmlentities($row->isbn);?></td>
                          
                           <td class=""><?php  echo htmlentities($row->title);?></td>
                           <td class=""><?php  echo $status;?></td>
                       
                          
                          <td class=" text-center"><!-- <a href="#"  class=" edit_data4" id="<?php echo  ($row->browids); ?>" title="click to edit"><i class="mdi mdi-pencil-box-outline" aria-hidden="true"></i> </a> -->
                           <!--  <a href="#"  class=" edit_data5" id="<?php echo  ($row->studentid); ?>" title="click to view">&nbsp;<i class="mdi mdi-eye" aria-hidden="true"></i></a>  -->
                            <a href="borrow.php?del=<?php echo $row->browids;?>" data-toggle="tooltip" data-original-title="Delete" onclick="return confirm('Do you really want to delete?');"> <i class="mdi mdi-delete"></i> </a>
                          </td>
                        </tr>
                        <?php 
                        $cnt=$cnt+1;
                      }
                    } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
      <!-- partial:../../partials/_footer.html -->
      <?php @include("includes/footer.php");?>
      <!-- partial -->
    </div>
    <!-- main-panel ends -->
  </div>
  <!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->
<?php @include("includes/foot.php");?>
<!-- End custom js for this page -->
<script type="text/javascript">
  $(document).ready(function(){
    $(document).on('click','.edit_data4',function(){
      var edit_id4=$(this).attr('id');
      $.ajax({
        url:"borrow_edit.php",
        type:"post",
        data:{edit_id4:edit_id4},
        success:function(data){
          $("#info_update4").html(data);
          $("#editData4").modal('show');
        }
      });
    });
  });
</script>
<script type="text/javascript">
  $(document).ready(function(){
    $(document).on('click','.edit_data5',function(){
      var edit_id5=$(this).attr('id');
      $.ajax({
        url:"borrow_view.php",
        type:"post",
        data:{edit_id5:edit_id5},
        success:function(data){
          $("#info_update5").html(data);
          $("#editData5").modal('show');
        }
      });
    });
  });
</script>

<script>
  function rem_select(){
    $('[name="isbn[]"]').change(function(){
      if($(this).val() == '<rem>'){
        $(this).closest('.form-group').remove()
      }
    })
  }
$(function(){
  $(document).on('click', '#append', function(e){
    e.preventDefault();
    var books = '<?php echo json_encode($brows) ?>';
    var _s = $('<select class="form-control" name="isbn[]"></select>')
    var _tmp = $('<div></div>')
    var option = '';
        option += '<option value="" selected disabled>Please Select Book here.</option>';
        option += '<option value="<rem>" >< remove select></option>';
        books = JSON.parse(books)
        if(books.length > 0){
          Object.keys(books).map(k=>{
            option  += '<option value="'+books[k].isbn+'">'+books[k].title+' ['+books[k].isbn+']'+'</option>'
          })
        }
        _s.append(option)
        _tmp.append(_s)
    
  
    $('#append-div').append(
      '<div class="form-group"><label for="" class="col-sm-3 control-label">ISBN</label><div class="col-sm-9">'+_tmp.html()+'</div></div>'
    );
    rem_select()
  });
});

</script>

</body>
</html>