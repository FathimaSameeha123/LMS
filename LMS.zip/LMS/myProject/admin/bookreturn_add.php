<?php
	include('includes/checklogin.php');
check_login();
	if(isset($_POST['save'])){
		$student = $_POST['student'];
		
		$sql = "SELECT * FROM tblstudents WHERE student_id = '$student'";
		$query = $con->query($sql);
		if($query->num_rows < 1){
			if(!isset($_SESSION['error'])){
				$_SESSION['error'] = array();
			}
			
			echo '<script>alert("Student not found")</script>';
		}
		else{
			$row = $query->fetch_assoc();
			$student_id = $row['id'];

			$return = 0;
			foreach($_POST['isbn'] as $isbn){
				if(!empty($isbn)){
					$sql = "SELECT * FROM tblbooks WHERE isbn = '$isbn'";
					$query = $con->query($sql);
					if($query->num_rows > 0){
						$brow = $query->fetch_assoc();
						$bid = $brow['id'];

						$sql = "SELECT * FROM tblborrow WHERE student_id = '$student_id' AND book_id = '$bid' AND status = 0";
						$query = $con->query($sql);
						if($query->num_rows > 0){
							$borrow = $query->fetch_assoc();
							$borrow_id = $borrow['id'];
							$sql = "INSERT INTO tblreturns (student_id, book_id, date_return) VALUES ('$student_id', '$bid', NOW())";
							if($con->query($sql)){
								$return++;
								$sql = "UPDATE tblbooks SET status = 0 WHERE id = '$bid'";
								$con->query($sql);
								$sql = "UPDATE tblborrow SET status = 1 WHERE id = '$borrow_id'";
								$con->query($sql);
							}
							else{
								if(!isset($_SESSION['error'])){
									$_SESSION['error'] = array();
								}
							
								// echo '<script>alert("Borrow details not found")</script>';
							}
						}
						else{
							if(!isset($_SESSION['error'])){
								$_SESSION['error'] = array();
							}
						
							echo '<script>alert("Borrow details not found: ISBN")</script>';
						}

						

					}
					else{
						if(!isset($_SESSION['error'])){
							$_SESSION['error'] = array();
						}
						
						echo '<script>alert("Book not found")</script>';
					}
		
				}
			}

			if($return > 0){
				$book = ($return == 1) ? 'Book' : 'Books';
				
				echo '<script>alert("successfully returned")</script>';
			}

		}
	}	
	else{
		
		echo '<script>alert(" Fill up add form first")</script>';
	}

	header('location: bookreturn.php');

?>