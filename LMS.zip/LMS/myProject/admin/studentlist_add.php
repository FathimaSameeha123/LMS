<?php
include('includes/checklogin.php');
check_login();

	if(isset($_POST['save'])){
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$student_id = $_POST['s_id'];
		$filename = $_FILES['photo']['name'];
		if(!empty($filename)){
			move_uploaded_file($_FILES['photo']['tmp_name'], './studenimages/'.$filename);	
		}
		
	
		$sql = "INSERT INTO tblstudents (student_id, firstname, lastname, photo, created_on) VALUES ('$student_id', '$firstname', '$lastname', '$filename', NOW())";
		if($con->query($sql)){
			
			 echo '<script>alert("Student added successfully")</script>';
		}
		else{
			$_SESSION['error'] = $con->error;
		}

	}
	else{
		
		 echo '<script>alert("Fill up add form first")</script>';
	}

	//header('location: studentlist.php');
	echo "<script>window.location.href='studentlist.php'</script>";
?>