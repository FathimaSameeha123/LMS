<?php
session_start();
//error_reporting(0);
include('includes/dbconnection.php');
if(isset($_POST['insert']))
{
    $eib= $_SESSION['editbid'];
    $heading=$_POST['heading'];
    $sql4="update tblslider_img set img_heading=:heading where img_id=:eib";
    $query=$dbh->prepare($sql4);
    $query->bindParam(':heading',$heading,PDO::PARAM_STR);
    $query->bindParam(':eib',$eib,PDO::PARAM_STR);
    $query->execute();
    if ($query->execute())
    {
        echo '<script>alert("updated successfuly")</script>';
    }else{
        echo '<script>alert("update failed! try again later")</script>';
    }
}
?>
<div class="card-body">
    <?php
    $eid=$_POST['edit_id4'];
    $sql2="SELECT * from tblslider_img where img_id=:eid";
    $query2 = $dbh -> prepare($sql2);
    $query2-> bindParam(':eid', $eid, PDO::PARAM_STR);
    $query2->execute();
    $results=$query2->fetchAll(PDO::FETCH_OBJ);
    if($query2->rowCount() > 0)
    {
        foreach($results as $row)
        {
            $_SESSION['editbid']=$row->img_id;
            ?>

            <form class="form-sample"  method="post" enctype="multipart/form-data">
                <div class="control-group">
                    <label class="control-label" for="basicinput"> Image</label>
                    <div class="controls">
                        <img style="height: 200px; width: 400px;" src="universityimages/<?php  echo $row->img;?>" width="150" height="100">
                        <!-- <a href="update_sliderimg.php?img=<?php echo ($row->img_id);?>">Change Image</a> -->
                    </div>
                </div>  
                <div>&nbsp;</div>
                
                
                
                
            </form>
            <?php 
        }
    } ?>
</div>