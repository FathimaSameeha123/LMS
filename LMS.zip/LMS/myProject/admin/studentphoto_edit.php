<?php
session_start();
//error_reporting(0);
include('includes/dbconnection.php');

  if(isset($_POST['update'])){
  $eib= $_SESSION['editbid'];
    $filename = date('YmdHis').$_FILES['photo']['name'];
    if(!empty($filename)){
      move_uploaded_file($_FILES['photo']['tmp_name'], './studenimages/'.$filename); 
    }
    
    $sql = "UPDATE tblstudents SET photo = '$filename' WHERE id = '$eib'";
    if($con->query($sql)){
      //$_SESSION['success'] = 'Student photo updated successfully';
      echo "<script>alert('Student photo updated successfully');</script>"; 
    }
    else{
      $_SESSION['error'] = $con->error;
    }

  }
  else{
    $_SESSION['error'] = 'Select student to update photo first';
     //echo "<script>alert('Select student to update photo first');</script>"; 
  }

?>
<div class="card-body">
 
  <?php
  $eid=$_POST['edit_id5'];
  //echo $eid;
  //$eid=3;
  $sql="SELECT * from tblstudents  where id=:eid";
  $query = $dbh -> prepare($sql);
  $query-> bindParam(':eid', $eid, PDO::PARAM_STR);
  $query->execute();
  $results=$query->fetchAll(PDO::FETCH_OBJ);
  if($query->rowCount() > 0)
  {
    foreach($results as $row)

        $photo = (!empty($row->photo )) ? './studenimages/'.($row->photo)  : './studenimages/profile.jpg';
      $_SESSION['editbid']=$row->id;
      {?>

        <h4 style="color: blue">Student Photo Update</h4>
         <form class="form-sample"  method="post" enctype="multipart/form-data">
        <table >
          <tr>

          
            <td><?php  echo ($row->firstname.''. ($row->lastname));?></td>
            <td><input type="hidden" name="photo" class="form-control"  value="<?php  echo $row->studid;?>" id="photo" placeholder="" required></td>
          </tr>
          
          <tr>
           
            <td><img src=<?php  echo $photo ?>. width='250px' height='150px'></td>
          </tr>

          <tr>
           
            <td><input type="file" name="photo" class="form-control" value="" id="photo" placeholder="" required></td>
          </tr>
        </table> 
<button type="submit" name="update" class="btn btn-primary btn-fw mr-2" style="float: left;">Update</button>
    </form>
        <?php 
      }
    } ?>
  </div>