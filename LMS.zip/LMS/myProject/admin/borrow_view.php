<?php
session_start();
//error_reporting(0);
include('includes/dbconnection.php');
?>
<div class="card-body">
 
  <?php
  $eid=$_POST['edit_id5'];
  //$eid=3;
  $sql="SELECT * from tblstudents  where id=:eid";
  $query = $dbh -> prepare($sql);
  $query-> bindParam(':eid', $eid, PDO::PARAM_STR);
  $query->execute();
  $results=$query->fetchAll(PDO::FETCH_OBJ);
  if($query->rowCount() > 0)
  {
    foreach($results as $row)
      {?>

        <h4 style="color: blue">Student Information</h4>
        <table border="1" class="table table-bordered">
          <tr>
            <th>Full Name</th>
            <td><?php  echo ($row->firstname.''. ($row->lastname));?></td>
          </tr>
          
          <tr>
            <th>Student Registration No</th>
            <td><?php  echo $row->student_id;?></td>
          </tr>

          
        </table> 
        <?php 
      }
    } ?>
  </div>