<?php 
include('includes/checklogin.php');
check_login();
 $today = date('Y-m-d');
  $year = date('Y');
  if(isset($_GET['year'])){
    $year = $_GET['year'];
  }
?>
<!DOCTYPE html>
<html lang="en">
<?php @include("includes/head.php");?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php @include("includes/header.php");?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php @include("includes/sidebar.php");?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-4 stretch-card grid-margin">
              <div class="card bg-gradient-success card-img-holder text-white" style="height: 150px;">
                <div class="card-body">
                  <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                  <h4 class="font-weight-normal mb-3">Total Books <i class="mdi mdi-library-books mdi-24px float-right"></i>
                  </h4>
                  <?php 
                  $sql ="SELECT * FROM tblbooks";
                  $query = $dbh -> prepare($sql);
                  $query->execute();
                  $results=$query->fetchAll(PDO::FETCH_OBJ);
                  $tblbooks=$query->rowCount();
                  ?>
                  <h2 class="mb-5"><?php echo htmlentities($tblbooks);?></h2>
                </div>
              </div>
            </div>
            <div class="col-md-4 stretch-card grid-margin">
              <div class="card bg-gradient-info card-img-holder text-white" style="height: 150px;">
                <div class="card-body">
                  <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                  <h4 class="font-weight-normal mb-3">Total Students  <i class="mdi mdi-library mdi-24px float-right"></i>
                  </h4>
                  <?php 
                  $sql ="SELECT * FROM tblstudents";
                  $query = $dbh -> prepare($sql);
                  $query->execute();
                  $results=$query->fetchAll(PDO::FETCH_OBJ);
                  $tblstudents=$query->rowCount();
                  ?>
                  <h2 class="mb-5"><?php echo htmlentities($tblstudents);?></h2>
                </div>
              </div>
            </div>

            <div class="col-md-4 stretch-card grid-margin">
              <div class="card bg-gradient-warning card-img-holder text-white" style="height: 150px;">
                <div class="card-body">
                  <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                  <h4 class="font-weight-normal mb-3">Returned Today  <i class="mdi mdi-replay mdi-24px float-right"></i>
                  </h4>
                  <?php 
                  $sql ="SELECT * FROM tblreturns WHERE date_return = '$today'";
                  $query = $dbh -> prepare($sql);
                  $query->execute();
                  $results=$query->fetchAll(PDO::FETCH_OBJ);
                  $tblreturns=$query->rowCount();
                  ?>
                  <h2 class="mb-5"><?php echo htmlentities($tblreturns);?></h2>
                </div>
              </div>
            </div>


            <div class="col-md-4 stretch-card grid-margin">
              <div class="card bg-gradient-danger card-img-holder text-white"style="height: 150px;">
                <div class="card-body">
                  <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                  <h4 class="font-weight-normal mb-3">Borrowed Today <i class="mdi mdi-send mdi-24px float-right"></i>
                  </h4>
                  <?php 
                  $sql ="SELECT * FROM tblborrow WHERE date_borrow = '$today'";
                  $query = $dbh -> prepare($sql);
                  $query->execute();
                  $results=$query->fetchAll(PDO::FETCH_OBJ);
                  $tblborrow=$query->rowCount();
                  ?>
                  <h2 class="mb-5"><?php echo htmlentities($tblborrow);?></h2>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <?php @include("includes/footer.php");?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <?php @include("includes/foot.php");?>
  s
</body>
</html>


