<?php 

session_start();
 //error_reporting(0);
include('admin/includes/dbconnection.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Library Management System  - About page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="" />
	
	<!-- css --> 
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<!-- <link rel="stylesheet" href="materialize/css/materialize.min.css" media="screen,projection" /> -->
	<link href="css/bootstrap.min.css" rel="stylesheet" />
	<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet"> 
	<link href="css/flexslider.css" rel="stylesheet" /> 
	<link href="css/style.css" rel="stylesheet" />


</head>
<body>
	<div id="wrapper"> 

		<!-- start header -->
		<?php include('includes/header.php') ?>
		<!-- end header -->
		<section id="inner-headline">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<h2 class="pageTitle">About Us</h2>
					</div>
				</div>
			</div>
		</section>
		<section id="content">
			<section class="section-padding">
				<div class="container">
					<div class="row showcase-section">
						<div class="col-md-6">
								<?php
                    $sql="SELECT * from tblslider_img where img_id='7'";
                    $query = $dbh -> prepare($sql);
                    $query->execute();
                    $results=$query->fetchAll(PDO::FETCH_OBJ);
                   
                    if($query->rowCount() > 0)
                    {
                      foreach($results as $row)
                      { ?>
							
						</div>
						<?php }}?>
						<div class="col-md-6">
							<div class="about-text">
								

								
								<p>Welcome to our Computerized Department Library Project! We are dedicated to revolutionizing the way information is managed and accessed within our department.</p>



 <h4> <span class="color"> Mission: </span> </h4>
Our mission is to provide efficient and streamlined access to information resources for students, faculty, and staff within the ICT department. Through the implementation of modern technology and innovative practices, we strive to enhance research, learning, and collaboration within our academic community.


<h4> <span class="color">Goals:</h4>
<p>- Streamline the process of cataloging and managing library materials</p>
<p>- Enhance the user experience for both library staff and patrons</p>
<p>-Simplify member registration and management.</p>
<p>-Enable efficient borrowing and return processes.</p>
<p>- Provide real-time availability status of books.</p>


<h4> <span class="color">Features:</span> </h4>
<p>- Advanced search and retrieval capabilities</p>
<p>- User-friendly interface for patrons and staff</p>
<p>- Simplified member registration and management.</p>
<p>- efficient borrowing and return processes.</p>
<h4> <span class="color">Contact Section:</span> </h4>
<p>We'd love to hear from you! If you have any questions, suggestions, or feedback, please feel free to reach out to our friendly staff by phone, email, or in person during your next visit.</p>

<h6>Stay Connected with our Library System by following us on</h6>
<p>Email:@DITlibrarymanagementsystem.com</p>
<p>Phone: +94 75 440 7151</p>

								
							</div>
						</div>
					</div>
				</div>
			</section>
		</section>
		
	</div>
	<a href="#" class="scrollup waves-effect waves-dark"><i class="fa fa-angle-up HillSide"></i></a>
	<script src="js/jquery.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="materialize/js/materialize.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.fancybox.pack.js"></script>
	<script src="js/jquery.fancybox-media.js"></script>  
	<script src="js/jquery.flexslider.js"></script>
	
	<!-- Vendor Scripts -->
	<script src="js/modernizr.custom.js"></script>
	<script src="js/jquery.isotope.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/custom.js"></script>
	<?php include 'includes/login_modal.php'; ?>
</body>
</html>