<?php
include 'includes/session.php';

	if(!isset($_SESSION['student']) || trim($_SESSION['student']) == ''){
		header('index.php');
	}

	$stuid = $student['id'];
	$sql = "SELECT * FROM tblborrow LEFT JOIN tblbooks ON tblbooks.id=tblborrow.book_id WHERE student_id = '$stuid' ORDER BY date_borrow DESC";
	$action = '';
	if(isset($_GET['action'])){
		$sql = "SELECT * FROM tblreturns LEFT JOIN tblbooks ON tblbooks.id=tblreturns.book_id WHERE student_id = '$stuid' ORDER BY date_return DESC";
		$action = $_GET['action'];
	}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Library Management System  - Home page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="" />
	
	<!-- css --> 
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<!-- <link rel="stylesheet" href="materialize/css/materialize.min.css" media="screen,projection" /> -->
	<link href="css/bootstrap.min.css" rel="stylesheet" />
	<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet"> 
	<link href="css/flexslider.css" rel="stylesheet" /> 
	<link rel="stylesheet" type="text/css" href="css/zoomslider.css" />
	<link href="css/style.css" rel="stylesheet" />
	<style>
  		.dataTables_filter {
			display: none; 
		}
  	</style>	
</head>
<body>
	<div id="wrapper" class="home-page"> 
		
		<!-- start header -->
		<?php include('includes/header.php') ?>
		<!-- end header -->
	
		<section class="projects">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="aligncenter"><h2 class="aligncenter">Search Books</h2></div>
						<br/>
					</div>
				</div>

				<div class="row service-v1 margin-bottom-40">
					<div class="row">
	        	<div class="col-sm-8 col-sm-offset-2">
	        		<?php
	        			if(isset($_SESSION['error'])){
	        				echo "
	        					<div class='alert alert-danger'>
	        						".$_SESSION['error']."
	        					</div>
	        				";
	        				unset($_SESSION['error']);
	        			}
	        		?>
	        		<div class="box">
	        			<div class="box-header with-border">
	        				<div class="input-group">
				                <input type="text" class="form-control input-lg" id="searchBox" placeholder="Search for ISBN, Title or Author">
				                <span class="input-group-btn">
				                    <button type="button" class="btn btn-primary btn-flat btn-lg"><i class="fa fa-search"></i> </button>
				                </span>
				            </div>
	        			</div>
	        			<div class="box-body">
	        				<div class="input-group col-sm-5">
				                <span class="input-group-addon">Category:</span>
				               <select class="form-control input-sm" id="transelect">
	        						<option value="borrow" <?php echo ($action == '') ? 'selected' : ''; ?>>Borrow</option>
	        						<option value="return" <?php echo ($action == 'return') ? 'selected' : ''; ?>>Return</option>
	        					</select>
				             </div>
	        				<table class="table table-bordered table-striped" id="example1">
			        			<thead>
			        				<th class="hidden"></th>
			        				<th>Date</th>
			        				<th>ISBN</th>
			        				<th>Title</th>
			        				<th>Author</th>
			        			</thead>
			        			<tbody>
			        			<?php
			        				$query = $con->query($sql);
			        				while($row = $query->fetch_assoc()){
			        					$date = (isset($_GET['action'])) ? 'date_return' : 'date_borrow';
			        					echo "
			        						<tr>
			        							<td class='hidden'></td>
			        							<td>".date('M d, Y', strtotime($row[$date]))."</td>
			        							<td>".$row['isbn']."</td>
			        							<td>".$row['title']."</td>
			        							<td>".$row['author']."</td>
			        						</tr>
			        					";
			        				}
			        			?>
			        			</tbody>
			        		</table>
	        			</div>
	        		</div>
	        	</div>
	        </div>
	
				</div>
			</div>
		</section>


	</div>
	<a href="#" class="scrollup waves-effect waves-dark"><i class="fa fa-angle-up HillSide"></i></a>
	<script src="js/jquery.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="materialize/js/materialize.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.fancybox.pack.js"></script>
	<script src="js/jquery.fancybox-media.js"></script>  
	<script src="js/jquery.flexslider.js"></script>
	
	<!-- Vendor Scripts -->
	<script src="js/modernizr.custom.js"></script>
	<script src="js/jquery.zoomslider.min.js"></script>
	<script src="js/jquery.isotope.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	
	<script src="js/custom.js"></script>

	<script src="admin/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="admin/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

<script>
	$('#transelect').on('change', function(){
		var action = $(this).val();
		if(action == 'borrow'){
			window.location = 'transaction.php';
		}
		else{
			window.location = 'transaction.php?action='+action;
		}
	});
</script>
<script>
  $(function () {
    $('#example1').DataTable()
  	var bookTable = $('#booklist').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : true,
      'ordering'    : true,
      'info'        : false,
      'autoWidth'   : false
    })

    $('#searchBox').on('keyup', function(){
    	bookTable.search(this.value).draw();
	});

  })
</script>
<?php include 'includes/login_modal.php'; ?>
</body>
</html>